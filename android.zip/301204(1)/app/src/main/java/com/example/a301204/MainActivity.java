package com.example.a301204;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    EditText nhapST, nhapMK, nhapNH;
    TextView txtxinchao, txtKQ, txtgioithieu;
    Button btnDN;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nhapST = (EditText) findViewById(R.id.nhapST);
        nhapMK = (EditText) findViewById(R.id.nhapMK);
        nhapNH = (EditText) findViewById(R.id.nhapNH);
        txtxinchao = (TextView) findViewById(R.id.txtxinchao);
        txtKQ = (TextView) findViewById(R.id.txtKQ);
        txtgioithieu = (TextView) findViewById(R.id.txtgioithieu);
        btnDN = (Button) findViewById(R.id.btnDN);
        btnDN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String stk = nhapST.getText().toString().toUpperCase();
                boolean is_check = is_number_plate(stk);
                if (is_check){
                    txtKQ.setText("Đăng nhập thành công");
                }
                else{
                    txtKQ.setText("Tài khoản không hợp lệ");
                }


            }
        });


    }

    private boolean is_number_plate(String hex)
    {
        String email_pattern="[0-9]";
        Pattern p=Pattern.compile(email_pattern);
        Matcher m=p.matcher(hex);
        return m.matches();
    }
}
